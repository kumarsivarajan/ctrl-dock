#!/bin/bash
clear
echo "Please wait, while the system is audited ...."

sh audit -o on -L -U "$1/OA/admin_pc_add_2.php" > audit.log

echo "The audit has been completed and the results submitted to $1"